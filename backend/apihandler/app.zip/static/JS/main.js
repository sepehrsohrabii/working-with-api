$(function(){
  $('#datepicker').datepicker();
});
$(document).ready(function(){

});